public interface AListener {
    void onPress(int x, int y);
    void onRelease();
    void onHover(int x, int y);
}